package com.demo.pickup.consumer;

import com.demo.pickup.model.Order;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class PickupConsumer {

    private final KafkaTemplate<String, Order> kafkaTemplate;

    @Value("${kafka.topic.order-status}")
    private String orderStatusTopic;

    /**
     * Listens for new orders published by the Order Service.
     * After processing, publishes a status update back to Order Service.
     * Topic: new-orders
     */
    @KafkaListener(
            topics = "${kafka.topic.new-orders}",
            groupId = "pickup-group",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void consumeNewOrder(
            @Payload Order order,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset
    ) {
        log.info("=== Pickup Service Received New Order ===");
        log.info("Topic: {} | Partition: {} | Offset: {}", topic, partition, offset);
        log.info("Order ID  : {}", order.getOrderId());
        log.info("Customer  : {}", order.getCustomerName());
        log.info("Item      : {} x{} @ ₹{}", order.getItem(), order.getQuantity(), order.getPrice());
        log.info("=========================================");

        // Simulate pickup processing
        processPickup(order);
    }

    private void processPickup(Order order) {
        log.info("Processing pickup for order: {}", order.getOrderId());

        // Step 1: Confirm order
        publishStatusUpdate(order, "CONFIRMED");

        // Step 2: Simulate dispatch (in real-world, this would be async/event-driven)
        publishStatusUpdate(order, "DISPATCHED");

        log.info("Pickup processing complete for order: {}", order.getOrderId());
    }

    private void publishStatusUpdate(Order order, String newStatus) {
        order.setStatus(newStatus);

        kafkaTemplate.send(orderStatusTopic, order.getOrderId(), order)
                .whenComplete((result, ex) -> {
                    if (ex != null) {
                        log.error("Failed to send status update for order {}: {}",
                                order.getOrderId(), ex.getMessage());
                    } else {
                        log.info("Status update published → orderId={} status={} offset={}",
                                order.getOrderId(),
                                newStatus,
                                result.getRecordMetadata().offset());
                    }
                });
    }
}
