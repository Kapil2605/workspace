package com.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.entity.User;
import com.ecommerce.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	// ================= REGISTER =================

	@GetMapping("/registerPage")
	public String showRegisterPage(Model model) {
		model.addAttribute("user", new User());
		return "register"; // register.jsp
	}

	@PostMapping("/registerSubmit")
	public String registerUser(@ModelAttribute("user") User user, Model model) {

		try {
			userService.register(user);

			model.addAttribute("success", "Registration successful!");
			return "login";

		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			return "register";
		}
	}

	// ================= LOGIN =================

	@GetMapping("/loginPage")
	public String showLoginPage() {
		return "login"; // login.jsp
	}

	@PostMapping("/loginSubmit")
	public String loginUser(@RequestParam("email") String email,
							@RequestParam("password") String password,
								Model model) {

		try {
			User user = userService.login(email, password);

			if (user.getRole().equals("ADMIN")) {
				return "reseller-dashboard";
			} else {
				return "customer-home";
			}

		} catch (Exception e) {
			model.addAttribute("error", "Invalid credentials!");
			return "login";
		}
	}

	// ================= LOGOUT =================
	@GetMapping("/logout")
	public String logout() {
		return "redirect:/login";
	}
}