<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Register | KodeCart</title>

<style>
body {
	font-family: Arial, sans-serif;
	margin: 0;
	background-color: #f3f3f3;
}

header {
	background-color: #232f3e;
	padding: 12px 25px;
	display: flex;
	align-items: center;
	justify-content: space-between;
}

.logo {
	color: white;
	font-weight: bold;
	text-decoration: none;
	font-size: 1.2rem;
}

.form-card {
	background: white;
	max-width: 450px;
	margin: 50px auto;
	padding: 30px;
	border-radius: 8px;
	box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
	border: 1px solid #ddd;
}

h2 {
	margin-top: 0;
	font-size: 22px;
	color: #111;
	border-bottom: 1px solid #eee;
	padding-bottom: 10px;
	text-align: center;
}

.field-group {
	margin-bottom: 15px;
}

label {
	display: block;
	font-weight: bold;
	margin-bottom: 5px;
	font-size: 13px;
	color: #333;
}

input, select {
	width: 100%;
	padding: 10px;
	border: 1px solid #888;
	border-radius: 4px;
	box-sizing: border-box;
	height: 40px;
}

input:focus, select:focus {
	border-color: #e77600;
	outline: none;
	box-shadow: 0 0 3px #e77600;
}

input[type="submit"] {
	width: 100%;
	background-color: #ffd814;
	border: 1px solid #fcd200;
	border-radius: 8px;
	padding: 12px;
	cursor: pointer;
	font-weight: bold;
	margin-top: 10px;
}

.footer {
	text-align: center;
	margin-top: 15px;
	font-size: 14px;
}

.footer a {
	color: #007185;
	text-decoration: none;
}

.footer a:hover {
	text-decoration: underline;
}
</style>

</head>

<body>

<header>
	<a href="#" class="logo">KodeCart</a>
</header>

<div class="form-card">
	<h2>Create Account</h2>

	<form action="registerSubmit" method="post">

		<div class="field-group">
			<label>Full Name</label>
			<input type="text" name="name" placeholder="Enter your name" required>
		</div>

		<div class="field-group">
			<label>Email</label>
			<input type="email" name="email" placeholder="Enter your email" required>
		</div>

		<div class="field-group">
			<label>Phone</label>
			<input type="text" name="phone" placeholder="Enter your phone number" required>
		</div>

		<div class="field-group">
			<label>Password</label>
			<input type="password" name="password" placeholder="Enter password" required>
		</div>

		<div class="field-group">
			<label>Select Role</label>
			<select name="role" required>
				<option value="">-- Select Role --</option>
				<option value="USER">User</option>
				<option value="ADMIN">Admin</option>
			</select>
		</div>

		<input type="submit" value="Register">
	</form>

	<div class="footer">
		Already have an account? <a href="loginPage">Login here</a>
	</div>
</div>

</body>
</html>