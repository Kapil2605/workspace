<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Login | KodeCart</title>

<style>
body {
	font-family: Arial;
	background: #f3f3f3;
}

.form-box {
	background: white;
	width: 350px;
	margin: 80px auto;
	padding: 25px;
	border-radius: 8px;
	box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

input {
	width: 100%;
	padding: 10px;
	margin-bottom: 10px;
	border: 1px solid #aaa;
	border-radius: 4px;
}

input[type="submit"] {
	background: #ffd814;
	border: none;
	cursor: pointer;
	font-weight: bold;
}

.footer {
	text-align: center;
	margin-top: 10px;
}
</style>

</head>

<body>

<div class="form-box">
	<h2>Login</h2>

	<form action="loginSubmit" method="post">
		<input type="email" name="email" placeholder="Email" required>
		<input type="password" name="password" placeholder="Password" required>
		<input type="submit" value="Login">
	</form>

	<div class="footer">
		New user? <a href="registerPage">Create account</a>
	</div>
</div>

</body>
</html>