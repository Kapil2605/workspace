<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>WElcome to ekart</title>
<a href="registerPage">Register</a>
<a href="loginPage">Login</a>
</head>
<body>
</body>
</html>