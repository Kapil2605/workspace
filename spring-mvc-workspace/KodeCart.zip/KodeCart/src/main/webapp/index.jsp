<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>KodeCart</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            height: 100vh;
            background: linear-gradient(135deg, #667eea, #764ba2);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            width: 350px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }

        h1 {
            margin-bottom: 10px;
            color: #333;
        }

        p {
            color: #777;
            margin-bottom: 30px;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        .login-btn {
            background: #667eea;
            color: white;
        }

        .login-btn:hover {
            background: #5a67d8;
        }

        .register-btn {
            background: #48bb78;
            color: white;
        }

        .register-btn:hover {
            background: #38a169;
        }

        .footer {
            margin-top: 20px;
            font-size: 13px;
            color: #aaa;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>KodeCart</h1>
    <p>Your One-Stop eCommerce Solution</p>

    <a class="btn login-btn" href="/loginPage">
        Login
    </a>

    <a class="btn register-btn" href="/registerPage">
        Register
    </a>

    <div class="footer">
        � 2026 KodeCart
    </div>
</div>

</body>
</html>